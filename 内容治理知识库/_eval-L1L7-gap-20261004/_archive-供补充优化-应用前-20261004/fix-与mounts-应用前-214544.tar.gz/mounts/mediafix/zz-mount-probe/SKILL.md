---
name: zz-mount-probe
description: 探针：如果你看到这条，说明 eval-mediafix 的 customSkillDirs 根确实被扫描了。
version: "0.0.1"
---

探针 skill，无实际功能。
