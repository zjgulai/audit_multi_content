---
id: cg-r-6f2500bc187d8fae
title: "[W-2.197] 措辞表达库：命中「交叉摇篮式适配场景：新手妈妈入门练习、早产儿或吮吸力气偏弱的宝宝」等 1 类表达"
collection: 3_措辞表达库
kb_class: [措辞表达库]
tier: L1
topic: 未登记规则码
kind: fact
summary: "[W-2.197] 判为「禁用/必须修改」（P1·未定级）：命中表达 1 条、证据单元 1 条；处理方式是「补充：该姿势的优点是视野开阔，便于观察和调整宝宝的含接动作」。状态 provisional、verification 待验证。"
owner: 法务
half_life_days: 180
valid_until: 2027-03-28
effective_from: 2026-09-29
evidence_level: L1
data_level: L2
sensitivity_level: L2
created_at: 2026-09-29
asks:
  - W-2.197 判什么、命中什么算违规
  - W-2.197 应该怎么改（合规替代写法）
  - W-2.197 的证据有几条、证据级是什么
  - W-2.197 是 P 几、风险等级是什么
  - 「交叉摇篮式适配场景：新手妈妈入门练习、早产儿或吮吸力气偏弱的宝宝」这类表述能不能用
not_proves: 不能证明该条已过新库的正式验收（新库 l3 全部为 provisional，l4 canonical 尚未写入）；不能证明该条可替代合规/法务意见；不能证明「W-2.197」以外的规则码（未命中 ≠ 合规）
forbidden: 不许把本条的 P 级/风险等级当成放行结论 —— 未命中本规则不等于内容合规；不许据本条的 suggested_replacement 直接外发文案，外发前仍需人工复核；不许把派生视图的字段改动当成新库改动（视图不写回）
evidence_group: rule
source:
  kind: feishu-base
  ref: "https://momcozy-in.feishu.cn/base/SKkkbdZi9aRuMzs7ob0cpSYHnQg?table=tbl8AI00JZO1iZtp"
  fingerprint: SKkkbdZi9aRuMzs7ob0cpSYHnQg/tbl8AI00JZO1iZtp
  record_ids: [recvoyJ6L9SpCE]
  captured_at: 2026-09-29
provenance:
  anchor: "kb/l3/candidates/rules.jsonl#r-6f2500bc187d8fae"
  confidence: 确定
pii:
  detected: false
  masked: false
  strategy: 未检出自然人信息：正文为广告文案/规则表述与专家修订记录，不含姓名、联系方式等个人数据；如后续来源变化需重新判定
rule_id: r-6f2500bc187d8fae
article_no: W-2.197
rule_code: ""
p_level: P1
risk_level: 未定级
risk_level_raw: unknown
risk_level_note: 源库 kb/l3 的 risk_level 为 unknown/空 —— 未做人工定级；本视图不据 P 级反推，故标未定级
evidence_level_note: 源库证据级 observation（单条修订对、单一来源）→ L1
rule_status: provisional
rule_verification: 待验证
support_count: 1
form: revision_pair
kb_type: wording
---

# [W-2.197] 措辞表达库：命中「交叉摇篮式适配场景：新手妈妈入门练习、早产儿或吮吸力气偏弱的宝宝」等 1 类表达

**条款号**：W-2.197　|　**规则码**：（未登记）　|　**rule_id**：`r-6f2500bc187d8fae`　|　**判定**：P1 · 未定级

## 规则原文（照抄新库，未改写）

原表述：交叉摇篮式适配场景：新手妈妈入门练习、早产儿或吮吸力气偏弱的宝宝；修订为：补充：该姿势的优点是视野开阔，便于观察和调整宝宝的含接动作；同样适用于早产儿或体重偏低的宝宝；修订原因：适配场景描述不完整，遗漏了该姿势的核心优点：便于观察宝宝的吸吮含接情况

## 命中表达（1 条；来源：规则行 forbidden_expression 拆分）

- `交叉摇篮式适配场景：新手妈妈入门练习、早产儿或吮吸力气偏弱的宝宝`

## 判为违规的依据

适配场景描述不完整，遗漏了该姿势的核心优点：便于观察宝宝的吸吮含接情况

## 处理方式 / 合规替代

补充：该姿势的优点是视野开阔，便于观察和调整宝宝的含接动作；同样适用于早产儿或体重偏低的宝宝

## 禁用表达汇总

交叉摇篮式适配场景：新手妈妈入门练习、早产儿或吮吸力气偏弱的宝宝

## 适用范围与证据

- 覆盖记录数：0
- 证据单元数：1（support_count 取新库值 1）
- 证据级（新库取值）：L1
- 验证状态（新库取值）：待验证 · 规则状态：provisional
- 形态：revision_pair　|　库：措辞表达库（wording）

## 证据单元明细（前 30 条，unit_id 可回查 kb/l2/units.jsonl）

- `ea538bdc37efc83ecefe`　#专家修订汇总表/recvoyJ6L9SpCE/修订位置（原文引用）　→ 【前】交叉摇篮式适配场景：新手妈妈入门练习、早产儿或吮吸力气偏弱的宝宝 【后】补充：该姿势的优点是视野开阔，便于观察和调整宝宝的含接动作；同样适用于早产儿或体重偏低的宝宝 【原因】适配场景描述不完整，遗漏了该姿势的核心优点：便于观察宝宝的吸吮含接情况

---

> 本条是**派生视图**（由 `kb/.work/gen-host-library.py` 从新库 l3/l5 生成），不是新库的权威条目。字段来源见 frontmatter 的 `provenance`。
