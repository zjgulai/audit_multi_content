---
id: cg-r-21786ac5aff9be34
title: "[M05] 措辞表达库：命中「hospital grade」等 5 类表达"
collection: 3_措辞表达库
kb_class: [措辞表达库]
tier: L1
topic: M05
kind: fact
summary: "[M05] 判为「禁用/必须修改」（P1·红）：命中表达 5 条、证据单元 45 条、覆盖记录 15 条；处理方式是「hospital/NICU 场景表述需事实依据，否则删除 ▸ hospital/medical grade 需认证依据，否则删除」。状态 provisional、verification 已支持。"
owner: 法务 + 渠道负责人
half_life_days: 90
valid_until: 2026-12-28
effective_from: 2026-09-29
evidence_level: L1
data_level: L2
sensitivity_level: L2
created_at: 2026-09-29
asks:
  - M05 判什么、命中什么算违规
  - M05 应该怎么改（合规替代写法）
  - M05 的证据有几条、证据级是什么
  - M05 是 P 几、风险等级是什么
  - 「hospital grade；hospital grade；hospital-grade」这类表述能不能用
not_proves: 不能证明该条已过新库的正式验收（新库 l3 全部为 provisional，l4 canonical 尚未写入）；不能证明该条可替代合规/法务意见；不能证明「M05」以外的规则码（未命中 ≠ 合规）
forbidden: 不许把本条的 P 级/风险等级当成放行结论 —— 未命中本规则不等于内容合规；不许据本条的 suggested_replacement 直接外发文案，外发前仍需人工复核；不许把派生视图的字段改动当成新库改动（视图不写回）
evidence_group: rule
complements:
  - cg-r-38148746d4e6516d
source:
  kind: feishu-base
  ref: "https://momcozy-in.feishu.cn/base/Lk3Qb8y2QaVyZns6gprcVNE9nA0?table=tblcbk4XiW6471YN"
  fingerprint: Lk3Qb8y2QaVyZns6gprcVNE9nA0/tblcbk4XiW6471YN
  record_ids: [recvuJYdObBgjg, recvuJYdObE8HQ, recvuJYdObLAH7, recvuJYdObLR6F, recvuJYdObN3eh, recvuJYdObWZ2t, recvuJYdObap8j, recvuJYdObjwvt, recvuJYdObm8DM, recvuJYdObopeN, recvuJYdObrjds, recvuJYdObv3UM, recvuJYdObx5aF, recvuJYeGRNKlW, recvuJYeGRNQ4L]
  captured_at: 2026-09-29
provenance:
  anchor: "kb/l3/candidates/rules.jsonl#r-21786ac5aff9be34"
  confidence: 确定
pii:
  detected: false
  masked: false
  strategy: 未检出自然人信息：正文为广告文案/规则表述与专家修订记录，不含姓名、联系方式等个人数据；如后续来源变化需重新判定
rule_id: r-21786ac5aff9be34
article_no: W-1.11
rule_code: M05
p_level: P1
risk_level: 红
risk_level_raw: 审慎·黄；高危·红
evidence_level_note: 源库证据级 synthesis，但只归属 1 个来源根（需 ≥2）→ 按加载器 E036 的口径降为 L1（单一来源，只能当线索）
rule_status: provisional
rule_verification: 已支持
support_count: 45
form: entry
kb_type: wording
---

# [M05] 措辞表达库：命中「hospital grade」等 5 类表达

**条款号**：W-1.11　|　**规则码**：M05　|　**rule_id**：`r-21786ac5aff9be34`　|　**判定**：P1 · 红

## 规则原文（照抄新库，未改写）

规则码 M05：命中「hospital grade；hospital grade,hospital-grade；hospital-grade；qualité hospitalière」判定为违规；处理：「hospital grade,hospital-grade」→ 删除/替换为：效果百分比/销量/评分声称需附测试来源与口径，否则删除（折扣百分比不在此列） ▸ hospital/medical grade 需认证依据，否则删除 ▸ 奶流/移除量/排空效率/漏奶/短时排乳类claim需W1自身对照数据（样本、对照、统计口径齐全），或改为放松叙事+限定语（may help/natural）；内部测试数值（28.2%/10%/70%）补齐前不得公开传播 ▸ 核验 IBCLC/专家身份、参与方式、程序设计依据与 COI 披露后再保留（含 expert-tuned/专家调校/专家程序） ▸ hospi；依据：M03 未标注来源的效果数据声明；M05 等级背书用语（需核实是否有对应认证）；M07 效率/漏奶/奶流/移除量/短时排乳类claim需W1自身对照数据（当前仅内部测试或外部研究，28.2%/10%/70%待补样本与统计），或限定为放松叙事

## 命中表达（5 条；来源：规则行 forbidden_expression 拆分）

- `hospital grade`
- `hospital grade`
- `hospital-grade`
- `hospital-grade`
- `qualité hospitalière`

## 判为违规的依据

M03 未标注来源的效果数据声明；M05 等级背书用语（需核实是否有对应认证）；M07 效率/漏奶/奶流/移除量/短时排乳类claim需W1自身对照数据（当前仅内部测试或外部研究，28.2%/10%/70%待补样本与统计），或限定为放松叙事；未补证据前需限定或删除；U01 含泌乳顾问/认证头衔，需核实是否真实合作；U03 涉及医院/NICU 场景，需核实临床适用性声明

## 处理方式 / 合规替代

hospital/NICU 场景表述需事实依据，否则删除 ▸ hospital/medical grade 需认证依据，否则删除

## 禁用表达汇总

hospital grade；hospital grade,hospital-grade；hospital-grade；qualité hospitalière

## 适用范围与证据

- 覆盖记录数：15
- 证据单元数：45（support_count 取新库值 45）
- 证据级（新库取值）：L1
- 验证状态（新库取值）：已支持 · 规则状态：provisional
- 形态：entry　|　库：措辞表达库（wording）

## 证据单元明细（前 30 条，unit_id 可回查 kb/l2/units.jsonl）

- `0e8a16219d4ff3533a03`　#广告文案明细/recvuJYdObBgjg/命中片段　→ M03:trusted by 6 million / M05:hospital grade,hospital-grade / M07:leak / U01:ibclc / U03:hospital
- `22c423514c6115838309`　#广告文案明细/recvuJYdObBgjg/修改建议　→ 效果百分比/销量/评分声称需附测试来源与口径，否则删除（折扣百分比不在此列） ▸ hospital/medical grade 需认证依据，否则删除 ▸ 奶流/移除量/排空效率/漏奶/短时排乳类claim需W1自身对照数据（样本、对照、统计口径齐全），或改为放松叙事+限定语（may help/natural）；内…
- `1d66935ecd9593edddb0`　#广告文案明细/recvuJYdObBgjg/命中原因　→ M03 未标注来源的效果数据声明；M05 等级背书用语（需核实是否有对应认证）；M07 效率/漏奶/奶流/移除量/短时排乳类claim需W1自身对照数据（当前仅内部测试或外部研究，28.2%/10%/70%待补样本与统计），或限定为放松叙事；未补证据前需限定或删除；U01 含泌乳顾问/认证头衔，需核实是否真实合作…
- `6b4197ce96afe9e9ffca`　#广告文案明细/recvuJYdObE8HQ/命中片段　→ U03:hospital / M05:hospital-grade
- `86fffe4fd0051ee76d9b`　#广告文案明细/recvuJYdObE8HQ/修改建议　→ hospital/NICU 场景表述需事实依据，否则删除 ▸ hospital/medical grade 需认证依据，否则删除
- `3af4617a2b255097f463`　#广告文案明细/recvuJYdObE8HQ/命中原因　→ U03 涉及医院/NICU 场景，需核实临床适用性声明；M05 等级背书用语（需核实是否有对应认证）
- `83567fde04cd15624368`　#广告文案明细/recvuJYdObLAH7/命中片段　→ H02:more milk / M03:28% more / U03:hospital / M05:hospital-grade / M02:strong suction
- `0e4f822e5938e9b930ef`　#广告文案明细/recvuJYdObLAH7/修改建议　→ 删除 more milk/增产催奶/催产素/长期奶量/裸奶阵排空承诺；合规替代为放松叙事+限定语，如 relaxation supports your natural let-down, which may help your flow（因为放松，自然奶阵可能更顺畅），只描述自然生理过程、不承诺产品带来结果；fa…
- `b614b843d78cca17e7f4`　#广告文案明细/recvuJYdObLAH7/命中原因　→ H02 催乳/增产/奶量产出承诺（含裸 more milk、催产素、长期奶量、裸奶阵/排空功效claim，无 FDA/临床证据）；放松叙事+限定语（natural let-down/may help）走 M07 语境守卫；M03 未标注来源的效果数据声明；U03 涉及医院/NICU 场景，需核实临床适用性声明；M…
- `90982d350aad97725948`　#广告文案明细/recvuJYdObLR6F/命中片段　→ M01: quiet/ M05:qualité hospitalière / U03:hospital
- `36cafd417cd1dd74a488`　#广告文案明细/recvuJYdObLR6F/修改建议　→ 静音表述改客观参数（as low as 48 dB），避免 whisper/silent/ultra-quiet 绝对化 ▸ hospital/medical grade 需认证依据，否则删除 ▸ hospital/NICU 场景表述需事实依据，否则删除
- `7b60b9ec21f3253b9a77`　#广告文案明细/recvuJYdObLR6F/命中原因　→ M01 静音程度夸大（建议改为 low noise / quiet mode）；M05 等级背书用语（需核实是否有对应认证）；U03 涉及医院/NICU 场景，需核实临床适用性声明
- `7b0e40488d0f07d009c5`　#广告文案明细/recvuJYdObN3eh/命中片段　→ H02:more milk / M03:28% more,top-rated / U03:hospital / M05:hospital-grade
- `1d5cbfa795a3f38a21cf`　#广告文案明细/recvuJYdObN3eh/修改建议　→ 删除 more milk/增产催奶/催产素/长期奶量/裸奶阵排空承诺；合规替代为放松叙事+限定语，如 relaxation supports your natural let-down, which may help your flow（因为放松，自然奶阵可能更顺畅），只描述自然生理过程、不承诺产品带来结果；fa…
- `feb416cc8feef2da93c1`　#广告文案明细/recvuJYdObN3eh/命中原因　→ H02 催乳/增产/奶量产出承诺（含裸 more milk、催产素、长期奶量、裸奶阵/排空功效claim，无 FDA/临床证据）；放松叙事+限定语（natural let-down/may help）走 M07 语境守卫；M03 未标注来源的效果数据声明；U03 涉及医院/NICU 场景，需核实临床适用性声明；M…
- `26b55ff34392053553a3`　#广告文案明细/recvuJYdObWZ2t/命中片段　→ H02:boost supply,more milk,triggers letdown / M03:top rated / M01:whisper,whisper-quiet / U03:hospital / M02:maximum suction / M05:hospital-grade
- `52ea2f1459692f2065bb`　#广告文案明细/recvuJYdObWZ2t/修改建议　→ 删除 more milk/增产催奶/催产素/长期奶量/裸奶阵排空承诺；合规替代为放松叙事+限定语，如 relaxation supports your natural let-down, which may help your flow（因为放松，自然奶阵可能更顺畅），只描述自然生理过程、不承诺产品带来结果；fa…
- `01e6bd468e30cbf95677`　#广告文案明细/recvuJYdObWZ2t/命中原因　→ H02 催乳/增产/奶量产出承诺（含裸 more milk、催产素、长期奶量、裸奶阵/排空功效claim，无 FDA/临床证据）；放松叙事+限定语（natural let-down/may help）走 M07 语境守卫；M03 未标注来源的效果数据声明；M01 静音程度夸大（建议改为 low noise / q…
- `8d3e3cb233f088af737b`　#广告文案明细/recvuJYdObap8j/命中片段　→ U03:hospital / M05:hospital-grade
- `a45bbd9689a14e97198a`　#广告文案明细/recvuJYdObap8j/修改建议　→ hospital/NICU 场景表述需事实依据，否则删除 ▸ hospital/medical grade 需认证依据，否则删除
- `5fe5a6f6b09fa8d304ec`　#广告文案明细/recvuJYdObap8j/命中原因　→ U03 涉及医院/NICU 场景，需核实临床适用性声明；M05 等级背书用语（需核实是否有对应认证）
- `0e65ccfa85ba801d9d92`　#广告文案明细/recvuJYdObjwvt/命中片段　→ M05:hospital grade / M07:leakage / U03:hospital
- `fd706b28f0725bd6b73c`　#广告文案明细/recvuJYdObjwvt/修改建议　→ hospital/medical grade 需认证依据，否则删除 ▸ 奶流/移除量/排空效率/漏奶/短时排乳类claim需W1自身对照数据（样本、对照、统计口径齐全），或改为放松叙事+限定语（may help/natural）；内部测试数值（28.2%/10%/70%）补齐前不得公开传播 ▸ hospital/…
- `835b722ea4eefc0f411b`　#广告文案明细/recvuJYdObjwvt/命中原因　→ M05 等级背书用语（需核实是否有对应认证）；M07 效率/漏奶/奶流/移除量/短时排乳类claim需W1自身对照数据（当前仅内部测试或外部研究，28.2%/10%/70%待补样本与统计），或限定为放松叙事；未补证据前需限定或删除；U03 涉及医院/NICU 场景，需核实临床适用性声明
- `1676e14f74a11ba01a49`　#广告文案明细/recvuJYdObm8DM/命中片段　→ H02:more milk / M03:best-selling / U03:hospital / M05:hospital-grade / M07:smoother milk flow
- `cfd7791be20aa4106085`　#广告文案明细/recvuJYdObm8DM/修改建议　→ 删除 more milk/增产催奶/催产素/长期奶量/裸奶阵排空承诺；合规替代为放松叙事+限定语，如 relaxation supports your natural let-down, which may help your flow（因为放松，自然奶阵可能更顺畅），只描述自然生理过程、不承诺产品带来结果；fa…
- `200015dee30a53b4939e`　#广告文案明细/recvuJYdObm8DM/命中原因　→ H02 催乳/增产/奶量产出承诺（含裸 more milk、催产素、长期奶量、裸奶阵/排空功效claim，无 FDA/临床证据）；放松叙事+限定语（natural let-down/may help）走 M07 语境守卫；M03 未标注来源的效果数据声明；U03 涉及医院/NICU 场景，需核实临床适用性声明；M…
- `b31654529354e8a8f117`　#广告文案明细/recvuJYdObopeN/命中片段　→ H02:more milk / M03:best-selling / U03:hospital / M05:hospital-grade
- `f24f764c3f95361fceb7`　#广告文案明细/recvuJYdObopeN/修改建议　→ 删除 more milk/增产催奶/催产素/长期奶量/裸奶阵排空承诺；合规替代为放松叙事+限定语，如 relaxation supports your natural let-down, which may help your flow（因为放松，自然奶阵可能更顺畅），只描述自然生理过程、不承诺产品带来结果；fa…
- `1f02dc71f1be519740b6`　#广告文案明细/recvuJYdObopeN/命中原因　→ H02 催乳/增产/奶量产出承诺（含裸 more milk、催产素、长期奶量、裸奶阵/排空功效claim，无 FDA/临床证据）；放松叙事+限定语（natural let-down/may help）走 M07 语境守卫；M03 未标注来源的效果数据声明；U03 涉及医院/NICU 场景，需核实临床适用性声明；M…
- …另有 15 条，见新库 rules.jsonl 的 evidence_units

---

> 本条是**派生视图**（由 `kb/.work/gen-host-library.py` 从新库 l3/l5 生成），不是新库的权威条目。字段来源见 frontmatter 的 `provenance`。
